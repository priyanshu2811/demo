// src/App.js
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import AddProduct from "./pages/AddProduct";
import UpdateStock from "./pages/UpdateStock";
import ViewInventory from "./pages/ViewInventory";
import RevokeOrder from "./pages/RevokeOrder";
import SalesAnalytics from "./pages/SalesAnalytics"; // Import the new page
import DefectiveProducts from "./pages/DefectiveProducts"; // Import the new page
import Login from "./pages/Login";
import Signup from "./pages/Signup";

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/login" element={< Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/add-product" element={<AddProduct />} />
          <Route path="/update-stock" element={<UpdateStock />} />
          <Route path="/view-inventory" element={<ViewInventory />} />
          <Route path="/revoke-order" element={<RevokeOrder />} />
          <Route path="/sales-analytics" element={<SalesAnalytics />} />
          <Route path="/defective-products" element={<DefectiveProducts />} /> {/* Add the route */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;

