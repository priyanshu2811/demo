const getApiUrl = () => {
    if (process.env.NODE_ENV == "production") {
      return '';
    } else {
      return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
    }
  }
  
  export default getApiUrl;