import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from '../pages/Home';
import About from '../pages/About';
import Contact from '../pages/Contact';
import Login from '../pages/Login';
import Signup from '../pages/Signup';
import Dashboard from '../pages/Dashboard';
import AddProduct from '../pages/AddProduct';
import UpdateStock from '../pages/UpdateStock';
import ViewInventory from '../pages/ViewInventory';
import RevokeOrder from '../pages/RevokeOrder'; // Import RevokeOrder component

const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/add-product" element={<AddProduct />} />
        <Route path="/update-stock" element={<UpdateStock />} />
        <Route path="/view-inventory" element={<ViewInventory />} />
        <Route path="/revoke-order" element={<RevokeOrder />} /> {/* Route for RevokeOrder */}
      </Routes>
    </Router>
  );
};

export default AppRoutes;