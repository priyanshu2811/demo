import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
// import { useInventoryState } from "../Context/InventoryContext";
import "./ViewInventory.css";
import getApiUrl from "../utils.js";

const ViewInventory = () => {
  // const { products = [], history = [] } = useInventoryState();
  const [product, setProduct] = useState([]);
  const [orderHistory, setOrderHistory] = useState([]);
  const [searchQueryInventory, setSearchQueryInventory] = useState("");
  const [searchQueryHistory, setSearchQueryHistory] = useState("");
  const navigate = useNavigate();
  const apiUrl = getApiUrl();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await fetch(`${apiUrl}/get-products`);
        const data = await res.json();
        // console.log("added-product data =>", data);
        setProduct(data);
      } catch (err) {
        console.log("Error in data fetching", err);
      }
    };

    

    const fetchOrderHistory = async () => {
      try {
        const res = await fetch(`${apiUrl}/get-history`);
        const getData = await res.json();
        // console.log("history data", getData);
        setOrderHistory(getData);
      } catch (err) {
        console.log(err);
      }
    };
    fetchProduct();
    fetchOrderHistory();
  }, []);

  const handleSearchInventory = (e) => {
    setSearchQueryInventory(e.target.value);
  };
  const handleSearchHistory = (e) => {
    setSearchQueryHistory(e.target.value);
  };

  // const filteredProducts = product.filter(
  //   (product) =>
  //     product.productClass
  //       .toLowerCase()
  //       .includes(searchQueryInventory.toLowerCase()) ||
  //     product.id.toString().includes(searchQueryInventory)
  // );

  // const filteredHistory = orderHistory.filter(
  //   (entry) =>
  //     entry.productName
  //       .toLowerCase()
  //       .includes(searchQueryHistory.toLowerCase()) ||
  //     entry.id.toString().includes(searchQueryHistory)
  // );

  const formatDate = (dateString) => {
    const options = {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
    };
    return new Date(dateString).toLocaleString(undefined, options);
  };
  return (
    <div className="view-inventory-container">
      <h1>View Inventory</h1>
      <div className="navigation-buttons">
        <button onClick={() => navigate("/dashboard")}>Dashboard</button>
        <button onClick={() => navigate("/add-product")}>Add Products</button>
        <button onClick={() => navigate("/update-stock")}>
          Punch In Order
        </button>
        <button onClick={() => navigate("/revoke-order")}>Revoke Order</button>
      </div>
      <input
        type="text"
        placeholder="Search by Product ID or Name"
        value={searchQueryInventory}
        onChange={handleSearchInventory}
        className="search-input"
      />
      <table>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Class</th>
            <th>Product Category</th>
            <th>Color</th>
            <th>Size</th>
            <th>Stock</th>
            <th>Price</th>
            {/* <th>Image</th> */}
          </tr>
        </thead>
        <tbody>
          {product.length === 0 ? (
            <tr>
              <td colSpan="7">No products found</td>
            </tr>
          ) : (
            product.map((item, index) => (
              <tr key={index}>
                <td>{item.id}</td>
                <td>{item.productClass}</td>
                <td>{item.productCat}</td>
                <td>{item.color}</td>
                <td>{item.size}</td>
                <td>{item.stock}</td>
                <td>{item.price}</td>
                {/* <td>
                  <img
                    src={item.image}
                    style={{ width: "50px", height: "50px" }}
                  />
                </td> */}
              </tr>
            ))
          )}
        </tbody>
      </table>

      <h2>Order History</h2>
      <input
        type="text"
        placeholder="Search by Product ID or Name"
        value={searchQueryHistory}
        onChange={handleSearchHistory}
        className="search-input"
      />
      <table>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Class</th>
            <th>Stock Before</th>
            <th>Stock After</th>
            <th>Sales</th>
            <th>Date</th>
            <th>Revoked</th>
            <th>Employee ID</th> {/* Add a column for Employee ID */}
          </tr>
        </thead>
        <tbody>
          {orderHistory.length === 0 ? (
            <tr>
              <td colSpan="9">No order history found</td>
            </tr>
          ) : (
            orderHistory.map((entry, index) => (
              <tr key={index}>
                <td>{entry.id}</td>
                <td>{entry.productClass}</td>
                <td>{entry.before_stock}</td>
                <td>{entry.after_stock}</td>
                <td>{entry.sales}</td>
                <td>{formatDate(entry.date)}</td>
                <td>{entry.revoked ? "Yes" : "No"}</td>
                <td>{entry.employee_id}</td> {/* Render the employee ID */}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default ViewInventory;
