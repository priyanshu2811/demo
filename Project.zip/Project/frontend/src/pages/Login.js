import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";
import getApiUrl from "../utils.js";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const apiUrl = getApiUrl();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      return window.alert("Fill the details");
    }

    const res = await fetch(`${apiUrl}/login`, {
      method: "POST",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify({
        email,
        password,
      }),
    });
    const data = await res.json();
    if (res.status === 200 && !data.err) {
      window.alert("Logged in successful");
      navigate("/dashboard");
    } else {
      window.alert("Invalid credentials");
    }
  };

  return (
    <>
      <video className="video-background" autoPlay muted loop>
        <source src="https://videos.pexels.com/video-files/5699536/5699536-sd_640_360_24fps.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="login-container">
        <img src={require('./logo.jpeg')} alt="Logo" className="logo-image" />
        <h1 className="mint-management">Mint Management</h1>
        <h2>Login</h2>
        <form onSubmit={handleSubmit} method="POST">
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit">Login</button>
        </form>
        <p>
          Don't have an account? <Link to="/signup">Sign Up</Link>
        </p>
      </div>
    </>
  );
};

export default Login;