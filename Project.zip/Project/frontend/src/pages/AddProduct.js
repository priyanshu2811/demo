// src/pages/AddProduct.js
import React, { useState, useEffect } from "react";
import { useInventoryDispatch } from "../Context/InventoryContext";
import { useNavigate } from "react-router-dom";
import "./AddProduct.css";
import getApiUrl from "../utils.js";

const AddProduct = () => {
  const dispatch = useInventoryDispatch();
  const [productCat, setProductCat] = useState("");
  const [productClass, setProductClass] = useState("");
  const [stock, setStock] = useState("");
  const [color, setColor] = useState("");
  const [size, setSize] = useState("");
  const [price, setPrice] = useState("");
  // const [productImage, setProductImage] = useState(null);
  const [productId, setProductId] = useState("");
  const navigate = useNavigate();
  // const [productDetails, setProductDetails] = useState(null);
  // const [productIds, setProductIds] = useState([]);
  const apiUrl = getApiUrl();

  const handleAddProduct = async (e) => {
    e.preventDefault();
    const newProduct = {
      productClass,
      productCat,
      color,
      size,
      stock: parseInt(stock, 10),
      price: parseFloat(price),
      // image: productImage,
      before_stocks: 0,
    };

    try {
      const res = await fetch(`${apiUrl}/add-products`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newProduct),
      });

      const data = await res.json();
      if (res.status === 200 && !data.err) {
        // If the product was added successfully, update the context and reset the form
        dispatch({
          type: "ADD_PRODUCT",
          payload: newProduct,
        });
        setProductClass("");
        setProductCat("");
        setStock("");
        setPrice("");
        setColor("");
        setSize("");

        // setProductImage("");
        return window.alert("Product added successfully");
      } else if (res.status === 202) {
        setProductClass("");
        setProductCat("");
        setStock("");
        setPrice("");
        setColor("");
        setSize("");
        // setProductImage("");
        return window.alert("added more stocks");
      } else if (res.status === 500) {
        return window.alert("Failed to add product");
      }
    } catch (error) {
      console.error("Error adding product:", error);
    }
  };

  return (
    <div className="add-product-container">
      <h2>Add Product</h2>
      <form onSubmit={handleAddProduct} method="POST">
        <div className="form-group">
          <label>Product Class</label>
          <input
            type="text"
            list="product-ids"
            value={productClass}
            onChange={(e) => setProductClass(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Product Category:</label>
          <input
            type="text"
            value={productCat}
            onChange={(e) => setProductCat(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Color:</label>
          <input
            type="text"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Size:</label>
          <input
            type="text"
            value={size}
            onChange={(e) => setSize(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Stock:</label>
          <input
            type="number"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Price:</label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>
        {/* <div className="form-group">
          <label>Image Upload:</label>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setProductImage(e.target.value)}
          />
        </div> */}

        <button type="submit">Add Product</button>
      </form>
      <div className="navigation-buttons">
        <button onClick={() => navigate("/dashboard")} className="nav-button">
          Dashboard
        </button>
        <button
          onClick={() => navigate("/update-stock")}
          className="nav-button"
        >
          Punch In Order
        </button>
        <button
          onClick={() => navigate("/view-inventory")}
          className="nav-button"
        >
          View Inventory
        </button>
        <button
          onClick={() => navigate("/revoke-order")}
          className="nav-button"
        >
          Revoke Order
        </button>
      </div>
    </div>
  );
};

export default AddProduct;
