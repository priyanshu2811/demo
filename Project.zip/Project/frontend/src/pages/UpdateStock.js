// import React, { useState, useEffect } from "react";
// import {
//   useInventoryState,
//   useInventoryDispatch,
// } from "../Context/InventoryContext";
// import { Link } from "react-router-dom";
// import "./UpdateStock.css";

// // Mock function to fetch employee data
// const fetchEmployees = () => {
//   return [
//     { id: "E001", name: "John Doe" },
//     { id: "E002", name: "Jane Smith" },
//     { id: "E003", name: "Alice Johnson" },
//     { id: "E004", name: "Dean Anthony" },
//     { id: "E005", name: "Mack Jutirod" },
//     { id: "E006", name: "Steve Yelon" },
//     // Add more employees as needed
//   ];
// };

// const UpdateStock = () => {
//   const { products } = useInventoryState();
//   const dispatch = useInventoryDispatch();
//   const [getProduct, setGetProduct] = useState([]);
//   const [selectedProductClass, setSelectedProductClass] = useState("");
//   const [selectedProductId, setSelectedProductId] = useState("");
//   const [sales, setSales] = useState("");
//   const [currentStock, setCurrentStock] = useState("");
//   const [employees, setEmployees] = useState([]);
//   const [selectedEmployeeId, setSelectedEmployeeId] = useState("");

//   useEffect(() => {
//     const fetchProduct = async () => {
//       try {
//         const res = await fetch("http://localhost:8000/get-products");
//         const data = await res.json();
//         setGetProduct(data);
//       } catch (err) {
//         console.error("Error fetching products:", err);
//       }
//     };
//     fetchProduct();
//   }, []);

//   useEffect(() => {
//     // Fetch employee data
//     const employeesData = fetchEmployees();
//     setEmployees(employeesData);
//   }, []);

//   const handleProductSelect = (selectedProduct) => {
//     const product = getProduct.find(
//       (p) =>
//         p.productCat === selectedProduct || p.id.toString() === selectedProduct
//     );
//     if (product) {
//       setCurrentStock(product.stock);
//     } else {
//       setCurrentStock("");
//     }
//   };

//   const handleUpdateStock = async (e) => {
//     e.preventDefault();
//     const product = getProduct.find(
//       (p) =>
//         p.productCat === selectedProductClass ||
//         p.id.toString() === selectedProductId
//     );

//     if (!product) {
//       console.error("Product not found for the given selection.");
//       return window.alert("Product not found");
//     }

//     const newStock = product.stock - parseInt(sales, 10);

//     // Check for valid sales
//     if (newStock < 0) {
//       return window.alert("Insufficient stock available.");
//     }

//     // Update stock in the backend
//     try {
//       const res = await fetch("http://localhost:8000/orders", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           id: product.id,
//           productCat: product.productCat,
//           stock: newStock,
//           sales: parseInt(sales, 10),
//           date: new Date(),
//           employee_id: selectedEmployeeId,
//         }),
//       });

//       const data = await res.json();
//       // console.log("Response data:", data);

//       if (res.status === 200) {
//         // Update local state
//         const updatedProducts = getProduct.map((p) =>
//           p.id === product.id ? { ...p, stock: newStock } : p
//         );
//         setGetProduct(updatedProducts);

//         dispatch({
//           type: "UPDATE_STOCK",
//           payload: {
//             id: product.id,
//             productName: product.productName,
//             stock: newStock,
//             sales: parseInt(sales, 10),
//             date: new Date(),
//             employeeId: selectedEmployeeId,
//           },
//         });
//         setSelectedProductClass("");
//         setSelectedProductId("");
//         setSales("");
//         setCurrentStock("");
//         setSelectedEmployeeId("");
//         return window.alert("Stock updated successfully");
//       } else {
//         return window.alert(`Failed to update stock: ${data.message}`);
//       }
//     } catch (error) {
//       console.error("Error updating stock:", error);
//       return window.alert("Failed to update stock");
//     }
//   };

//   return (
//     <div className="update-stock-container">
//       <h2>Update Stock</h2>
//       <form onSubmit={handleUpdateStock}>
//         <div className="form-group">
//           <label>Product by Class:</label>
//           <select
//             value={selectedProductClass}
//             onChange={(e) => {
//               setSelectedProductClass(e.target.value);
//               setSelectedProductId("");
//               handleProductSelect(e.target.value);
//             }}
//           >
//             <option value="">Select a product by class</option>
//             {getProduct.map((product) => (
//               <option key={product.id} value={product.productClass}>
//                 {product.productClass}
//               </option>
//             ))}
//           </select>
//         </div>
//         <div className="form-group">
//           <label>Product by ID:</label>
//           <select
//             value={selectedProductId}
//             onChange={(e) => {
//               setSelectedProductId(e.target.value);
//               setSelectedProductClass("");
//               handleProductSelect(e.target.value);
//             }}
//           >
//             <option value="">Select a product by ID</option>
//             {getProduct.map((product) => (
//               <option key={product.id} value={product.id}>
//                 {product.id}
//               </option>
//             ))}
//           </select>
//         </div>
//         {currentStock !== "" && (
//           <div className="form-group">
//             <label>Current Stock:</label>
//             <p>{currentStock}</p>
//           </div>
//         )}
//         <div className="form-group">
//           <label>Sales:</label>
//           <input
//             type="number"
//             value={sales}
//             onChange={(e) => setSales(e.target.value)}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label>Select Employee:</label>
//           <select
//             value={selectedEmployeeId}
//             onChange={(e) => setSelectedEmployeeId(e.target.value)}
//           >
//             <option value="">Select an employee by ID</option>
//             {employees.map((employee) => (
//               <option key={employee.id} value={employee.id}>
//                 {employee.id} - {employee.name}
//               </option>
//             ))}
//           </select>
//         </div>
//         <button type="submit">Update Stock</button>
//       </form>
//       <Link to="/view-inventory">
//         <button>View Inventory</button>
//       </Link>
//     </div>
//   );
// };

// export default UpdateStock;

import React, { useState, useEffect } from "react";
import {
  useInventoryState,
  useInventoryDispatch,
} from "../Context/InventoryContext";
import { Link } from "react-router-dom";
import "./UpdateStock.css";
import getApiUrl from "../utils.js";


const UpdateStock = () => {
  // const { products } = useInventoryState();
  // const dispatch = useInventoryDispatch();
  const [getProduct, setGetProduct] = useState([]);
  const [selectedProductClass, setSelectedProductClass] = useState("");
  const [selectedProductId, setSelectedProductId] = useState("");
  const [sales, setSales] = useState("");
  const [currentStock, setCurrentStock] = useState("");
  const [employees, setEmployees] = useState([]);
  const apiUrl = getApiUrl();
  // const [selectedEmployeeId, setSelectedEmployeeId] = useState("");

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await fetch(`${apiUrl}/get-products`);
        const data = await res.json();
        setGetProduct(data);
      } catch (err) {
        console.error("Error fetching products:", err);
      }
    };
    fetchProduct();
  }, []);

  const handleProductSelect = (selectedProduct) => {
    const product = getProduct.find(
      (p) =>
        p.productClass === selectedProduct ||
        p.id.toString() === selectedProduct
    );
    if (product) {
      setCurrentStock(product.stock);
    } else {
      setCurrentStock("");
    }
  };

  const handleUpdateStock = async (e) => {
    e.preventDefault();
    const product = getProduct.find(
      (p) =>
        p.productClass === selectedProductClass ||
        p.id.toString() === selectedProductId
    );

    if (!product) {
      console.error("Product not found for the given selection.");
      return window.alert("Product not found");
    }

    const newStock = product.stock - parseInt(sales, 10);

    // Check for valid sales
    if (newStock < 0) {
      return window.alert("Insufficient stock available.");
    }

    // Update stock in the backend
    try {
      const res = await fetch(`${apiUrl}/orders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: product.id,
          productCat: product.productCat,
          stock: newStock,
          sales: parseInt(sales, 10),
          date: new Date(),
          employee_id: employees,
        }),
      });

      const data = await res.json();
      // console.log("Response data:", data);

      if (res.status === 200) {
        // Update local state
        const updatedProducts = getProduct.map((p) =>
          p.id === product.id ? { ...p, stock: newStock } : p
        );
        setGetProduct(updatedProducts);

        // dispatch({
        //   type: "UPDATE_STOCK",
        //   payload: {
        //     id: product.id,
        //     productName: product.productName,
        //     stock: newStock,
        //     sales: parseInt(sales, 10),
        //     date: new Date(),
        //     employeeId: selectedEmployeeId,
        //   },
        // });
        setSelectedProductClass("");
        setSelectedProductId("");
        setSales("");
        setCurrentStock("");
        setEmployees("");
        return window.alert("Stock updated successfully");
      } else {
        return window.alert(`Failed to update stock: ${data.message}`);
      }
    } catch (error) {
      console.error("Error updating stock:", error);
      return window.alert("Failed to update stock");
    }
  };

  return (
    <div className="update-stock-container">
      <h2>Update Stock</h2>
      <form onSubmit={handleUpdateStock}>
        <div className="form-group">
          <label>Product by Class:</label>
          <select
            value={selectedProductClass}
            onChange={(e) => {
              setSelectedProductClass(e.target.value);
              setSelectedProductId("");
              handleProductSelect(e.target.value);
            }}
          >
            <option value="">Select a product by class</option>
            {getProduct.map((product) => (
              <option key={product.id} value={product.productClass}>
                {product.productClass}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label>Product by ID:</label>
          <select
            value={selectedProductId}
            onChange={(e) => {
              setSelectedProductId(e.target.value);
              setSelectedProductClass("");
              handleProductSelect(e.target.value);
            }}
          >
            <option value="">Select a product by ID</option>
            {getProduct.map((product) => (
              <option key={product.id} value={product.id}>
                {product.id}
              </option>
            ))}
          </select>
        </div>
        {currentStock !== "" && (
          <div className="form-group">
            <label>Current Stock:</label>
            <p>{currentStock}</p>
          </div>
        )}
        <div className="form-group">
          <label>Sales:</label>
          <input
            type="number"
            value={sales}
            onChange={(e) => setSales(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Enter Employee Id:</label>
          <input
            type="text"
            value={employees}
            onChange={(e) => setEmployees(e.target.value)}
            required
          />
        </div>
        <button type="submit">Update Stock</button>
      </form>
      <Link to="/view-inventory">
        <button>View Inventory</button>
      </Link>
    </div>
  );
};

export default UpdateStock;
