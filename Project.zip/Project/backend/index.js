const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const cors = require("cors");
const fs = require("fs").promises;
const path = require("path");
const products = require("./data/products.json");
const registerDetail = require("./data/register.json");
const product_list = require("./data/products_list.json");

const app = express();
const PORT = 8000;

dotenv.config({ path: "./config.env" });
app.use(cors());
// Middleware to parse JSON bodies
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'build')));

// to connect database
// require("./db/conn");

// to change in the json file
const productsFilePath = path.join(__dirname, "./data/products.json");
// const addedProductFilePath = path.join(__dirname, "./data/added-products.json");
const defectiveFilePath = path.join(
  __dirname,
  "./data/defective-quantity.json"
);
const ordersFilePath = path.join(__dirname, "./data/orders.json");


const readJSONFile = async (filePath) => {
  try {
    const data = await fs.readFile(filePath, "utf8");
    return JSON.parse(data);
  } catch (error) {
    throw new Error(`Error reading file from disk: ${error}`);
  }
};

const writeJSONFile = async (filePath, data) => {
  try {
    fs.writeFile(filePath, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    throw new Error(`Error writing file to disk: ${error}`);
  }
};

app.post("/signup", async (req, res) => {
  const { email, password, confirmPassword } = req.body;

  if (!email || !password || !confirmPassword) {
    return res.status(422).json({ error: "fill the all fields!" });
  }

  try {
    // to check if user exists
    const userExist = registerDetail.find(
      (register) => register.email === email
    );

    if (userExist) {
      return res.status(422).json({ message: "user already exists!" });
    } else if (password != confirmPassword) {
      return res.status(422).json({ message: "password does not match" });
    } else {
      registerDetail.push({ id: registerDetail.length + 1, ...req.body });
      fs.writeFile(
        "./data/register.json",
        JSON.stringify(registerDetail),
        (err, data) => {
          // return res.json({ status: "sent" });
        }
      );
      // await user.save(); // save user data for registration

      res.status(201).json({ message: "User Registration Successful" });
    }
  } catch (err) {
    console.log(err);
  }
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  // console.log("Body", body);
  if (!email || !password) {
    return res.status(400).json({ message: "Fill the details" });
  }

  try {
    const userExist = registerDetail.find(
      (register) => register.email === email
    );

    // console.log("userExist", userExist);
    const passConfirm = registerDetail.find(
      (pass) => pass.password === password
    );
    // console.log("passconfirm", passConfirm);

    if (userExist) {
      if (passConfirm) {
        // loginDetail.push({ id: loginDetail.length + 1, ...req.body });
        // fs.writeFile(
        //   "./data/login.json",
        //   JSON.stringify(loginDetail),
        //   (err, data) => {
        //     return res.status(200).json({ message: "Logged In successfully" });
        //   }
        // );
        return res.status(200).json({ message: "Logged In successfully" });
      } else {
        return res.status(401).json({ message: "Invalid credenttails" });
      }
    } else {
      return res.status(400).json({ message: "No such user exist" });
    }
  } catch (err) {
    console.log(err);
  }
});

// for addProduct.js to get id, name and price automatically from the backend
app.get("/product-list/:id", (req, res) => {
  try {
    const productId = Number(req.params.id);
    const product = product_list.find((p) => p.id === productId);
    if (product) {
      res.status(200).json(product);
    } else {
      res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    res.status(500).json({
      message: "Error fetching product details",
      error: error.message,
    });
  }
});

app.post("/add-products", async (req, res) => {
  const body = req.body;
  console.log("body->", body);
  const { productCat, stock, color, size } = req.body;

  const products = await readJSONFile(productsFilePath);

  // console.log("products => add-prodcts", products);

  const prodExist = products.find((p) => p.productCat === productCat);
  console.log("prodExist", prodExist);

  if (prodExist) {
    // adding more stocks

    prodExist.stock += stock;
    await writeJSONFile(productsFilePath, products);
    res.status(202).json({ message: "added more stocks" });
  } else {
    try {
      // const addedProducts = await readJSONFile(addedProductFilePath);

      const newProduct = { id: productCat + " " + color + " " + size, ...body };
      products.push(newProduct);
      // addedProducts.push(newProduct);

      await writeJSONFile(productsFilePath, products);
      // await writeJSONFile(addedProductFilePath, addedProducts);

      res.json({ status: "Product added successfully" });
    } catch (error) {
      res
        .status(500)
        .json({ message: "Failed to add product", error: error.message });
    }
  }
});

app.post("/orders", async (req, res) => {
  const { productCat, sales, employee_id, id } = req.body;

  // Check for missing fields
  if (!sales || !employee_id) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    const existingProducts = await readJSONFile(productsFilePath);
    const orders = await readJSONFile(ordersFilePath);

    // Find the product
    const product = existingProducts.find((p) => p.id === id);
    // console.log("product->", product);
    // Check if product exists and if there is sufficient stock
    if (!product || sales < 1 || product.stock < sales) {
      return res
        .status(400)
        .json({ message: "Product unavailable or insufficient stock" });
    }

    const beforeStock = product.stock;
    const afterStock = product.stock - sales;

    // Update product stock
    product.stock = afterStock;

    // Add the new order
    orders.push({
      id: id,
      productCat,
      productClass: product.productClass,
      before_stock: beforeStock,
      after_stock: afterStock,
      sales,
      date: new Date().toISOString(),
      employee_id,
    });

    // Write updates to files
    await writeJSONFile(productsFilePath, existingProducts);
    await writeJSONFile(ordersFilePath, orders);

    // Send response
    res.json({ status: "Order placed successfully" });
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ message: "An error occurred", error: error.message });
  }
});

app.post("/revoke-order", async (req, res) => {
  const { id, date, revokeOrder } = req.body;

  try {
    // Read orders and products from file
    const orders = await readJSONFile(ordersFilePath);
    const products = await readJSONFile(productsFilePath);

    // Find the order to revoke
    const orderIndex = orders.findIndex(
      (order) => order.id === id && order.date === date
    );

    if (orderIndex === -1) {
      return res.status(404).json({ message: "Order not found" });
    }

    const order = orders[orderIndex];

    // Find the corresponding product
    const productIndex = products.findIndex(
      (product) => product.productName === order.productName
    );

    if (productIndex === -1) {
      return res.status(404).json({ message: "Product not found" });
    }

    // Update the stock in the products file
    const product = products[productIndex];
    product.stock += order.sales;

    // Update the after_stock field in the orders file
    orders[orderIndex].revoked = true;
    orders[orderIndex].revokeOrder = revokeOrder;

    orders[orderIndex].after_stock = product.stock;

    // changes done by me
    orders[orderIndex].sales = 0;

    // orders[orderIndex].sales = sales - revokeOrder;

    // Write back the updated orders and products to their files
    await writeJSONFile(ordersFilePath, orders);
    await writeJSONFile(productsFilePath, products);

    res.json({ status: "Order revoked successfully" });
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ message: "An error occurred", error: error.message });
  }
});

app.get("/get-products", async (req, res) => {
  try {
    const products = await readJSONFile(productsFilePath);
    res.json(products);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching products", error: error.message });
  }
});

app.get("/get-history", async (req, res) => {
  try {
    const history = await readJSONFile(ordersFilePath);
    res.json(history);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching order history", error: error.message });
  }
});

app.get("/sales-data", async (req, res) => {
  try {
    const orders = await readJSONFile(ordersFilePath);
    res.json(orders);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to fetch sales data", error: error.message });
  }
});

app.post("/defective-product", async (req, res) => {
  const { id, quantity } = req.body;

  try {
    const products = await readJSONFile(productsFilePath);
    const defectiveQuantity = await readJSONFile(defectiveFilePath);

    if (!Array.isArray(products)) {
      return res.status(500).json({ message: "Products data is not an array" });
    }

    const product = products.find((p) => p.id === id);

    console.log("ID from request:", id);
    console.log(
      "Product IDs:",
      products.map((p) => p.id)
    );

    if (product) {
      product.stock = Math.max(product.stock - quantity, 0);

      // changes by me

      // if (!product.defective) {
      //   product.defective = 0;
      // }

      // // Increase the defective quantity
      // product.defective += quantity;
      defectiveQuantity.push({
        id: id,
        defective: quantity,
        date: new Date(),
      });
      await writeJSONFile(productsFilePath, products);
      await writeJSONFile(defectiveFilePath, defectiveQuantity);

      return res.status(200).json(product);
    } else {
      return res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ message: "An error occurred", error: error.message });
  }
});

app.get("/get-defective", async (req, res) => {
  try {
    const defective = await readJSONFile(defectiveFilePath);
    res.json(defective);
  } catch (error) {
    res.status(500).json({
      message: "Error fetching defective product",
      error: error.message,
    });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
