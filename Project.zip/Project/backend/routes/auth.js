const express = require("express");
const router = express.Router();
// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");
// const authenticate = require("../middleware/authenticate");
// const cookieParser = require("cookie-parser");
// router.use(cookieParser());

router.get("/", (req, res) => {
  res.send("hello from server");
});

router.post("/register", async (req, res) => {
  const { username, email, phone, password, cpassword } = req.body;

  if (!username || !email || !phone || !password || !cpassword) {
    return res.status(422).json({ message: "fill all the fields" });
  }

  if (password !== cpassword) {
    return res.status(401).json({ message: "password not matched" });
  }

  try {
    const userExist = await User.find({ email: email });

    if (userExist) {
      return res.status(409).json({ message: "User already exist" });
    } else {
      const user = new User({ username, email, phone, password, cpassword });
      await user.save();
      res.status(201).json({ message: "User Registration Successful" });
    }
  } catch (err) {
    console.log(err);
  }
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res
      .status(400)
      .json({ error: "Username and password are required" });
  }

  // const csvLine = `${username},${password}\n`;
  const body = req.body;

  // const filePath = path.join(__dirname, "logins.csv");
  fs.appendFile("login.json", body, (err) => {
    if (err) {
      return res.status(500).json({ error: "Failed to save credentials" });
    }
    res.status(200).json({ message: "Credentials saved successfully" });
  });
});

// app.get("/product/:id", (req, res, next) => {
//   const id = req.params.id;
//   const user = products.map((product) => {
//     product.id == id;
//   });
//   return res.json(user);
// });

app.post("/products", async (req, res) => {
  const { name, price, description, stock, category } = req.body;

  const csvLine = `${name},${price},${description},${stock},${category}`;

  fs.appendFile("products.csv", csvLine, (err) => {
    if (err) {
      return res.status(500).json({ error: "Failed to save product " });
    }
    res.status(200).json({ message: "Product detail saved" });
  });

  // try {
  //   const newProduct = new Product({
  //     name,
  //     price,
  //     description,
  //     stock,
  //     category,
  //   });

  //   const savedProduct = await newProduct.save();
  //   res.status(201).json(savedProduct);
  // } catch (error) {
  //   res.status(400).json({ error: error.message });
  // }
});

app.post("/orders", async (req, res) => {
  const { orderId, customer, items, totalAmount, status } = req.body;
  const csvLine = `${orderId},${customer},${items},${totalAmount}, ${status}\n`;

  // const filePath = path.join(__dirname, "logins.csv");
  fs.appendFile("orders.csv", csvLine, (err) => {
    if (err) {
      return res.status(500).json({ error: "Failed to save credentials" });
    }
    res.status(200).json({ message: "Order Successfully" });
  });

  // try {
  //   const newOrder = new Order({
  //     orderId,
  //     customer,
  //     items,
  //     totalAmount,
  //     status,
  //   });

  //   const savedOrder = await newOrder.save();
  //   res.status(201).json(savedOrder);
  // } catch (error) {
  //   res.status(400).json({ error: error.message });
  // }
});
